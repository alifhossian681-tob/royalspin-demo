const express = require("express");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, "royalspin.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS demo_state (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    credits INTEGER NOT NULL,
    bonus_claimed INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);
db.prepare("INSERT OR IGNORE INTO demo_state (id, credits, bonus_claimed) VALUES (1, 10000, 0)").run();

app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public")));

const getState = db.prepare("SELECT credits, bonus_claimed FROM demo_state WHERE id = 1");
const getActivity = db.prepare("SELECT message, created_at AS createdAt FROM activity ORDER BY id DESC LIMIT 8");
const addActivity = db.prepare("INSERT INTO activity (message) VALUES (?)");
function state() {
  const row = getState.get();
  return { credits: row.credits, bonusClaimed: Boolean(row.bonus_claimed), activity: getActivity.all() };
}
app.get("/api/health", (_req, res) => res.json({ ok: true, mode: "virtual-credit-demo" }));
app.get("/api/state", (_req, res) => res.json(state()));

app.post("/api/refill", (_req, res) => {
  const tx = db.transaction(() => {
    db.prepare("UPDATE demo_state SET credits = credits + 1000 WHERE id = 1").run();
    addActivity.run("Refilled 1,000 virtual credits");
  });
  tx();
  res.json(state());
});

app.post("/api/bonus", (_req, res) => {
  const tx = db.transaction(() => {
    const row = getState.get();
    if (row.bonus_claimed) return false;
    db.prepare("UPDATE demo_state SET credits = credits + 500, bonus_claimed = 1 WHERE id = 1").run();
    addActivity.run("Claimed 500 virtual bonus credits");
    return true;
  });
  if (!tx()) return res.status(409).json({ error: "The demo bonus has already been claimed." });
  res.json(state());
});

const allowedGames = new Set(["Sugar Garden", "Temple Quest", "Lucky Wheel", "Card Match", "Sky Sprint", "Gem Dash"]);
app.post("/api/play", (req, res) => {
  const game = typeof req.body.game === "string" ? req.body.game.trim() : "";
  if (!allowedGames.has(game)) return res.status(400).json({ error: "Unknown demo game." });
  addActivity.run("Played " + game + " demo round");
  res.json(state());
});

app.use("/api", (_req, res) => res.status(404).json({ error: "API route not found." }));
app.listen(PORT, () => console.log(`RoyalSpin demo running at http://localhost:${PORT}`));

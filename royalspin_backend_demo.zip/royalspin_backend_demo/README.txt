ROYALSPIN — Backend + SQLite demo

This is a learning prototype for virtual credits only. It does not provide real-money betting, deposits, withdrawals, cash prizes, payment processing, or production user accounts.

Requirements
- Node.js 18 or newer
- npm

Run locally
1. Extract the ZIP.
2. Open a terminal in the extracted `royalspin_backend_demo` folder.
3. Install dependencies: `npm install`
4. Start the server: `npm start`
5. Open http://localhost:3000

What is included
- `server.js`: Express API
- `public/index.html`: responsive demo interface
- `royalspin.sqlite`: created automatically at first run
- API endpoints:
  - GET `/api/health`
  - GET `/api/state`
  - POST `/api/refill` adds 1,000 virtual credits
  - POST `/api/bonus` grants a one-time 500-credit demo bonus
  - POST `/api/play` records one of the allowed demo games

Database
SQLite persists the single shared demo wallet and activity log between server restarts. This starter does not implement separate user accounts, authentication, CSRF protection, or rate limiting; do not expose it publicly as-is. Before adding accounts or deploying publicly, add secure authentication, per-user ownership, rate limiting, request validation, HTTPS, backups, and privacy/security review. Keep credits strictly non-transferable and non-redeemable.
